create view aircrafts(aircraft_code, model, range) as
SELECT aircraft_code,
       model ->> lang() AS model,
       range
FROM aircrafts_data ml;

comment on view aircrafts is 'Aircrafts';

comment on column aircrafts.aircraft_code is 'Aircraft code, IATA';

comment on column aircrafts.model is 'Aircraft model';

comment on column aircrafts.range is 'Maximal flying distance, km';

alter table aircrafts
    owner to postgres;

