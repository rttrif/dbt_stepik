create procedure full_load()
    language plpgsql
as
$$
	declare
		current_update_dt timestamp = now();
	begin
		call staging.airports_load(current_update_dt);
		call staging.aircrafts_load(current_update_dt);
		call staging.seats_load(current_update_dt);
		call staging.flights_load(current_update_dt);
		call staging.ticket_flights_load(current_update_dt);
		call staging.boarding_passes_load(current_update_dt);
	end;
$$;

alter procedure full_load() owner to postgres;

