create view fct_ticket_flights(ticket_no, flight_id, fare_conditions, amount) as
SELECT ticket_no,
       flight_id,
       fare_conditions,
       amount
FROM bookings_dbt.stg_booking__ticket_flights;

alter table fct_ticket_flights
    owner to postgres;

