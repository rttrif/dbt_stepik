create materialized view actor_info_mater as
SELECT a.actor_id,
       a.first_name,
       a.last_name,
       a.last_update,
       a.test_column
FROM actor a
         LEFT JOIN film_actor fa ON a.actor_id = fa.actor_id
         LEFT JOIN film_category fc ON fa.film_id = fc.film_id
         LEFT JOIN category c ON fc.category_id = c.category_id
GROUP BY a.actor_id, a.first_name, a.last_name;

alter materialized view actor_info_mater owner to postgres;

